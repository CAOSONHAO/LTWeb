package service;

public class UserService {
//    private final UserDao userDao;
//
//    public UserService(UserDao userDao) {
//        this.userDao = userDao;
//    }
//
//    public boolean register(User user) {
//        return userDao.register(user);
//    }
//
//    public Optional<User> login(String username, String password) {
//        return userDao.login(username, password);
//    }
}
