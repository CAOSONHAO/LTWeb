package model;

public enum Role {
    CUSTOMER,
    ADMIN
}
